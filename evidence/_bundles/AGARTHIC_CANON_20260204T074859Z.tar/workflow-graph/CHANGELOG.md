# flowversion-workflow-graph-reference Changelog

## 0.1.0

- spec_version: 0.1.0
- canon_version: 0.1.0
- Initial release.

