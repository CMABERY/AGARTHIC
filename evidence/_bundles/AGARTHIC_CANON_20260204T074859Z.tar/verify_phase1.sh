#!/usr/bin/env bash
# verify_phase1.sh
# Phase 1.3: Zero-state deployability verification
#
# D1.5 RESOLUTION: C — This script invokes make db-apply as the
#                      authoritative I1 verification entrypoint.
#
# INVARIANT TESTED: I1 - make db-apply works on fresh Postgres
#
# USAGE: ./verify_phase1.sh
# REQUIRES: Docker (or podman-docker), bash, make, psql
# EXIT: 0 = PASS, 1 = FAIL

set -euo pipefail

CONTAINER_NAME="cpo-phase1-verify-$$"
DB_NAME="cpo_verify"
DB_USER="postgres"
DB_HOST="localhost"
DB_PASSWORD="verify_test_$(date +%s)"
DB_PORT="${DB_PORT:-5433}"

# Choose a free host port starting at DB_PORT
while ss -ltn 2>/dev/null | awk '{print $4}' | grep -q ":${DB_PORT}$"; do
  DB_PORT=$((DB_PORT+1))
done

cleanup() {
  echo ""
  echo "[CLEANUP] Removing container $CONTAINER_NAME..."
  docker rm -f "$CONTAINER_NAME" 2>/dev/null || true
}
trap cleanup EXIT

echo "============================================================"
echo "Phase 1.3: Zero-State Deployability Verification"
echo "D1.5 Resolution: C — Using make db-apply as entrypoint"
echo "============================================================"
echo ""

# Verify Makefile exists
if [ ! -f "Makefile" ]; then
  echo "[ERROR] Makefile not found in current directory"
  echo "[ERROR] Run this script from the repository root"
  exit 1
fi

# Verify make is available
if ! command -v make &> /dev/null; then
  echo "[ERROR] 'make' command not found"
  exit 1
fi

# ── psqlq: correct psql wrapper ──────────────────────────────────────────────
# This function form ensures PGPASSWORD is set as an environment variable
# (not treated as a command name, which is what happens with the
# PSQL="PGPASSWORD=... psql ..." string expansion pattern).
psqlq() {
  PGPASSWORD="$DB_PASSWORD" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -t -A "$@"
}

# 1. Start fresh Postgres
echo "[STEP 1] Starting fresh Postgres 15 container on port ${DB_PORT}..."
docker run -d \
  --name "$CONTAINER_NAME" \
  -e POSTGRES_PASSWORD="$DB_PASSWORD" \
  -e POSTGRES_DB="$DB_NAME" \
  -p "${DB_PORT}:5432" \
  docker.io/library/postgres:15 >/dev/null

echo "[STEP 1] Waiting for Postgres to be ready..."
for i in {1..30}; do
  if docker exec "$CONTAINER_NAME" pg_isready -U postgres >/dev/null 2>&1; then
    echo "[STEP 1] ✓ Postgres ready on port $DB_PORT"

echo "[STEP 1] Waiting for Postgres to accept SQL connections..."
for i in {1..30}; do
  if psqlq -c "SELECT 1" >/dev/null 2>&1; then
    echo "[STEP 1] ✓ Postgres accepts SQL connections"
    break
  fi
  if [ "$i" -eq 30 ]; then
    echo "[STEP 1] ✗ FAILED: Postgres did not accept SQL connections in time"
    echo "[DEBUG] Last psql output:"
    psqlq -c "SELECT 1" 2>&1 || true
    exit 1
  fi
  sleep 1
done

    break
  fi
  if [ "$i" -eq 30 ]; then
    echo "[STEP 1] ✗ FAILED: Postgres did not become ready"
    exit 1
  fi
  sleep 1
done

# 2. Run make db-apply (THE AUTHORITATIVE ENTRYPOINT)
echo ""
echo "[STEP 2] Running: make db-apply"
echo "============================================================"

export DB_HOST
export DB_PORT
export DB_USER
export DB_NAME
export DB_PASSWORD

if make db-apply; then
  echo ""
  echo "[STEP 2] ✓ make db-apply completed successfully"
else
  echo ""
  echo "[STEP 2] ✗ FAILED: make db-apply returned non-zero"
  exit 1
fi

# 3. Additional verification queries
echo ""
echo "[STEP 3] Running additional verification..."
echo "============================================================"

# Count migrations applied (action_logs table should exist and be empty)
TABLE_EXISTS=$(psqlq -c "SELECT EXISTS (SELECT 1 FROM pg_tables WHERE schemaname = 'cpo' AND tablename = 'cpo_action_logs');" 2>/dev/null || echo "f")
if [ "$TABLE_EXISTS" = "t" ]; then
  echo "[STEP 3] ✓ cpo_action_logs table exists"
else
  echo "[STEP 3] ✗ FAILED: cpo_action_logs table not found (TABLE_EXISTS='$TABLE_EXISTS')"
  echo "[STEP 3]   Debug: DB_HOST=$DB_HOST DB_PORT=$DB_PORT DB_USER=$DB_USER DB_NAME=$DB_NAME"
  exit 1
fi

# Verify commit_action function exists
FUNC_EXISTS=$(psqlq -c "SELECT EXISTS (SELECT 1 FROM pg_proc p JOIN pg_namespace n ON p.pronamespace = n.oid WHERE n.nspname = 'cpo' AND p.proname = 'commit_action');" 2>/dev/null || echo "f")
if [ "$FUNC_EXISTS" = "t" ]; then
  echo "[STEP 3] ✓ cpo.commit_action function exists"
else
  echo "[STEP 3] ✗ FAILED: cpo.commit_action function not found"
  exit 1
fi

# Verify bootstrap_verify returns expected structure
BOOTSTRAP_OK=$(psqlq -c "SELECT (cpo.bootstrap_verify()->>'tables_ok')::boolean;" 2>/dev/null || echo "f")
if [ "$BOOTSTRAP_OK" = "t" ]; then
  echo "[STEP 3] ✓ cpo.bootstrap_verify() returns tables_ok=true"
else
  echo "[STEP 3] ✗ FAILED: bootstrap_verify did not return tables_ok=true"
  exit 1
fi

# 4. Summary
echo ""
echo "============================================================"
echo "PHASE 1.3 VERIFICATION: ✓ PASSED"
echo "============================================================"
echo ""
echo "Invariant I1 (zero-state deployability) is satisfied."
echo "The full migration chain (MIGRATION_ORDER.md) applies cleanly"
echo "on a fresh Postgres instance via 'make db-apply'."
echo ""
echo "Files applied: 25 (3 migrations + 22 patches)"
echo "Tables created: 13+ in cpo schema"
echo "Functions created: commit_action, bootstrap_verify, ..."
echo ""

exit 0
