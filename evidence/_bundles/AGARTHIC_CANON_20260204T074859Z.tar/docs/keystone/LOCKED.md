# LOCKED

This directory is canonically locked.

- SPEC_VERSION: 1.0.0
- CANON_VERSION: 1

Any modification requires a new versioned initiation phase (Phase 0 reset) and re-proof of invariants.
